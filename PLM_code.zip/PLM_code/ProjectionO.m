function y = ProjectionO(x, a, b)
%% The projection of x at [a b]
%% a and b are the low bound and upper bound,re spectively.
%  
x(x>b) = b;
x(x<a) = a;

y = x;

end