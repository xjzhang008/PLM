% locally quadratic approxiamtion  SCAD
% for some a>2, x>0

function y = ET(gamma,x)

y = gamma*exp(-gamma*abs(x))/(1-exp(-gamma));

end