function [X, Allite,ii, Rel, ObjA, y] = IPLM(Xbar, Omega, opts)
%% An proximal linearized minimmization algorithm for nonconvex tensor completion 
%% A Nonconvex Relaxation Approach to Low-Rank Tensor Completion, Xiongjun Zhang,
%% IEEE TRANSACTIONS ON NEURAL NETWORKS AND LEARNING SYSTEMS, VOL. 30, NO. 6, JUNE 2019 1659-1671
%% Copyright: Xiongjun Zhang, email: xjzhang@mail.ccnu.edu.cn

%%
if nargin < 4; opts = []; end
opts = getopts(opts);


[m1 m2] = size(Xbar);

N = opts.N;
itemax = opts.itemax;
tol = opts.tol;
outtol = opts.outtol;

gamma = opts.gamma;
theta = opts.theta;
a = min(Xbar(:));
b = max(Xbar(:));
rho = opts.rho;


X0 = zeros(m1,m2);
X0(Omega) = Xbar(Omega);
T10 = X0;
T20 = X0;
y = ones(min(m1,m2),1);

Rel = [];
ObjA = [];

Allite = 0;

for ii = 1:N
    
    X00 = X0;
    
    if ii == 1
        beta1 = 10/sqrt(m1*m2);
%         beta2 = 10/sqrt(m1*m2);  % 0.05
%         beta2 = 10/sqrt(m1*m2);  % 0.075
%         beta2 = 10/sqrt(m1*m2);  % 0.1
        beta2 = 10/sqrt(m1*m2);  % 0.125
    else
        beta1 = 100/sqrt(m1*m2);
%         beta2 = 300/sqrt(m1*m2);  % 0.05
%         beta2 = 300/sqrt(m1*m2);  % 0.075
%         beta2 = 5000/sqrt(m1*m2);  % 0.1
        beta2 = 5000/sqrt(m1*m2);  % 0.125
    end
    
    lambda = 1/beta1;
    
    
    for k = 1:itemax
       % compute Y

       Y  = WSVD(X0 - T10/beta1,y,lambda);

       % Compute Z

       Z = ProjectionO(X0 - T20/beta2, a, b);

       % Compute X

       X = (rho*X00 + T10 + T20 + beta1*Y + beta2*Z)/(rho + beta1 + beta2);
       X(Omega) = Xbar(Omega);

       % updata the multipliers
       T1 = T10 - gamma*beta1*(X - Y);
       T2 = T20 - gamma*beta2*(X - Z);

       reler = norm(X(:) - X0(:))/norm(X0(:));
       ReTru = norm(X(:) - Xbar(:))/norm(Xbar(:));
       
       if reler < tol
          break;
       end
       
       if mod(k,10) == 0
          fprintf('iteration: %d\n',k);
          fprintf('Relative error: %f Error: %f\n',reler, ReTru);
       end

      % update varibles
      T10 = T1;
      T20 = T2;
      X0 = X;
      
      k = k + 1;
      Allite = Allite + 1;

    end
    
    Relout = norm(X(:)-X00(:))/norm(X00(:));
    Relout1 = norm(X(:)-Xbar(:))/norm(Xbar(:));
    
    if Relout < outtol
          break
    end
    
    [U D1 V] = svd(X0,'econ');
    D1 = diag(D1);
    y = ET(theta,D1);
    Rel = [Rel, Relout1];
    Obj = sum(ones(size(D1))- exp(-theta.*(D1)))/(1-exp(-theta));
    ObjA = [ObjA,Obj];
    
    ii = ii + 1;
%     theta = 5*theta;
    
end

%% ------------------SUBFUNCTION-----------------------------
function opts = getopts(opts)

if ~isfield(opts,'itemax')
    % maximum inner iteration number of ADMM 
    opts.itemax = 80;
end

if ~isfield(opts,'tol')
    % inner iteration relative error
    opts.tol = 1e-4;
end

if ~isfield(opts,'outtol')
    % inner iteration relative error
    opts.outtol = 1e-4;
end

if ~isfield(opts,'N')
    % maximum outer iterative number
    opts.N = 6;
end

if ~isfield(opts,'rho')
    % proximal term coefficient
    opts.rho = 1e-6;
end

if ~isfield(opts,'theta')
 %         opts.theta = 0.05;  %%  0.225
%       opts.theta = 0.05;  %%  0.125
%         opts.theta = 0.08;  %%  0.125
%     opts.theta = 0.05;  %%  0.1
     opts.theta = 0.08;   %% 0.05
%     opts.theta = 0.03;   %% 0.075    
end

if ~isfield(opts,'gamma')
    opts.gamma = 1.618;
end

