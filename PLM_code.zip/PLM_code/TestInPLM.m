%% An proximal linearized minimmization algorithm for nonconvex tensor completion 
%% A Nonconvex Relaxation Approach to Low-Rank Tensor Completion, Xiongjun Zhang,
%% IEEE TRANSACTIONS ON NEURAL NETWORKS AND LEARNING SYSTEMS, VOL. 30, NO. 6, JUNE 2019 1659-1671
%% Copyright Xiongjun Zhang, email: xjzhang@mail.ccnu.edu.cn

warning off
addpath('tensor_toolbox_2.6');

%% generate a tensor 
load ocean.mat
AAA = tensor(ocean);


group = [2,3];
MM = tenmat(AAA,group); %square norm
AA = double(MM.data)/255; % true matrix
dim = size(AA)

DD = double(AAA.data);  % true tensor
DD = DD/255;
Nway = size(DD);
[N1, N2, N3, N4] = size(DD);



Omega = zeros(Nway);
%load matlab;
%mark = A;
%%mark = ones(256,256)-mark;
%mark = logical(mark);
ratio = 0.15;
a = N1; b = N2;

%mark=repmat(mark, [1 1 3]); mark=logical(mark);
for i = 1:N4
    temp=randperm(a*b);k=round((1-ratio)*a*b);
    mark = zeros(a, b); mark(temp(1:k))=1;
    Omega(:,:,1,i) = mark;
    Omega(:,:,2,i) = mark;
    Omega(:,:,3,i) = mark;
end


Omega = logical(Omega);
m = (N1*N2-k)*N3*N4;
Omega = find(Omega==0);
[n1 n2] = size(Omega);

% p = round(ratio*prod(Nway));
% Omega = randsample(prod(Nway),p);

%% Parameter setting
beta = 200/sqrt(prod(Nway));  % penalty parameter
maxiter = 100;                % maximum iteration number
gamma = 1.618;                % step length
relerr = 1e-3;                % relative error

%% initial value

%% main iteration

% ---------------------------------output parameters------------------
disp('The matlab is running...')
fprintf('The penalty parameter is %4.4f\n',beta)
fprintf('The sample ratio is %4.4f\n',ratio)
fprintf('Generated the initial estimator......\n');

tic;
[X, Allite, ii, Rel, ObjA, y] = IPLM(AA, Omega);
toc;

Xrec = tensor(tenmat(X,MM.rdims,MM.cdims,MM.tsize));

PSNR = psnr(X(:),AA(:));
fprintf('PSNR = %0.8e\n',PSNR);

a = reshape(Xrec.data(:,:,:,10),[N1 N2 N3]);
imshow(a,[])
