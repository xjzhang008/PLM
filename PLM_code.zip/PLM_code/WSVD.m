function Y = WSVD(X,y,lambda)
% compute the weighted shrinkage operator
% min lambda\sum y_isigma_i(Y) + \|Y-X\|_F^2

[U D V] = svd(X,'econ');
D = diag(D);
D = max(D-lambda*y,0);
D = diag(D);
Y = U*D*V';

end