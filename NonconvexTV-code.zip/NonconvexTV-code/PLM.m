function out = PLM(H,F,beta,I,opts)
% out = PLM(H,F,beta,I,opts);
%% % A proximal linearized minimzation (PLM) algorithm to solve the
% NonconvexTV model
%% % Alternating Directions Method of Multipliers (ADMM) is applied 
%% to solve the subproblem, which refers to the ADMM for solving TVL1 by J. Yang, W. Yin, and Y. Zhang (2009)
% 
% Suppose the data accuquisition model is given by: F = N(K*Xbar),
% where Xbar is an original image, K is a convolution matrix, N(cdot)
% represents a procedure of impulsive noise corruption, and F is 
% a blurry and noisy observation. To recover Xbar from F and K, 
% we solve NonconvexTV model
% 
% ***     min_X \sum_j P(|K_jX - F_j|) + \sum_i ||Di*X||       ***
% 
% Inputs:
%         I  ---  original image
%         H  ---  convolution kernel representing K
%         F  ---  blurry and noisy observation
%         mu ---  the prameter in P (must be provided by user)
%         gamma ---  the prameter in P (must be provided by user)
%         opts --- a structure containing algorithm parameters {default}
%                 * opst.beta1   : a positive constant 
%                 * opst.beta2   : a positive constant
%                 * opst.gamma   : a constant in (0,1.618] {1.618}
%                 * opst.maxitr  : maximum iteration number {500}
%                 * opst.relchg  : a small positive parameter which controls
%                                  stopping rule of the code. When the
%                                  relative change of X is less than
%                                  opts.relchg, then the code stops. {1.e-3}
%                 * opts.print   : print inter results or not {1}
% 
% Outputs:
%         out --- a structure contains the following fields
%                * out.snr   : SNR values at each iteration
%                * out.f     : function valuse at each itertion
%                * out.tv    : TV values at each iteration
%                * out.fid   : fidelity values at each iteration
%                * out.relchg: the history of relative change in X
%                * out.sol   : numerical solution obtained by this code
%                * out.itr   : number of iterations used
%
%  @copyright X. Zhang, M. Bai and M. K. Ng, SIAM Journal on Iamging Sciences, 10(3):1627-1667, 2017.
% 


[m n] = size(F);

if nargin < 6; opts = []; end
opts = getopts(opts);

C = getC(F,H); 
[D,Dt] = defDDt;

% initialization
 gamma = 90;  % 30%, 



X = F;
Lam1 = zeros(m,n);
Lam2 = Lam1;
Lam3 = Lam1;

delta = opts.delta;
print = opts.print;
rho = opts.rho;       % parameter of the proximal term
N = opts.N;           % maximun outer iteration number of PLM

% finite diff
[D1X,D2X] = D(X);
KXF = imfilter(X,H,'circular','conv') - F;
[tv,fid,f] = fval(D1X,D2X,KXF,beta,gamma);

out.FX = [];
out.PSNR = [];
out.snr = [];
out.nrmdX = [];
out.relchg = [];
out.tv = tv;
out.fid = fid;
% X00 = zeros(m,n);
AllIte = 0;



%% Main loop
for k = 0:N
      KWF1 = imfilter(X,H,'circular','conv') - F;
      KWF2 = abs(KWF1);
      Weigh = ET(gamma,KWF2);
      X00 = X;

      if k ==0
          
          alpha1 = 5;
           alpha2 = 20;    % 30%
          Denom = C.eigsDtD + alpha2/alpha1 * C.eigsKtK + + rho * C.proI;

          
      else
          
          alpha1 = 5;
          alpha2 = 50000;    % 30%
%           alpha2 = 8000;    % 50%
%          alpha2 = 50;     % 70%
%          alpha2 = 150000;   %   90%
          Denom = C.eigsDtD + alpha2/alpha1 * C.eigsKtK + rho * C.proI;
      end

     for ii = 1:opts.maxitr

         
         % =======   Y = (Y1, Y2)  ==========
         V1 = D1X + Lam1/alpha1;
         V2 = D2X + Lam2/alpha1;
         V3 = KXF + Lam3/alpha2;

         V = V1.^2 + V2.^2;
         V = sqrt(V);
         V(V==0) = 1;

         % ==================
         %   Shrinkage Step
         % ==================
         V = max(V - 1/alpha1, 0)./V;
         Y1 = V1.*V;
         Y2 = V2.*V;

 
         % =======  Z  ==========
         Z = max(abs(V3) - (beta.*Weigh)/alpha2, 0).*sign(V3);
         
         % ==================
         %     X-subprolem
         % ==================
         Xp = X;
         Temp = (alpha2*Z - Lam3)/alpha1;
         Temp = imfilter(Temp,H,'circular','corr');
         X = Dt(Y1 - Lam1/alpha1,Y2 - Lam2/alpha1) + Temp + alpha2/alpha1*C.KtF + rho * X00;
         X = fft2(X)./Denom;
         X = real(ifft2(X));

         
         % % relative error for ADMM
         relchg = norm(X - Xp,'fro')/norm(X,'fro');
         out.relchg = [out.relchg; relchg];

         if print 
             fprintf('Iter: %d, snrX: %4.2f, relchg: %4.2e\n',ii,snrX,relchg);
         end

          % ====================
          % Check stopping rule for ADMM
          % ====================
          if relchg < opts.relchg
             out.sol = X;
             out.itr = ii;
             [D1X,D2X] = D(X);
             KXF = imfilter(X,H,'circular','conv') - F;
             break
          end

          % finite diff.
          [D1X,D2X] = D(X);
          KXF = imfilter(X,H,'circular','conv') - F;

         % ==================
         %    Update Lam
         % ==================
         Lam1 = Lam1 - delta*alpha1*(Y1 - D1X);
         Lam2 = Lam2 - delta*alpha1*(Y2 - D2X);
         Lam3 = Lam3 - delta*alpha2*(Z - KXF);
         
         
         % count all the iterations number
         AllIte = AllIte + 1;
 
     end
        out.sol = X;
        out.itr = k;
        out.allit = AllIte;
        out.exit = 'Exist Normally';
        
     if ii == opts.maxitr
        out.exit = 'Maximum iteration reached!';
     end
     
     % ======= check stopping criterion for PLM 
     rell = norm(X(:)-X00(:))/norm(X00(:));
     
     if rell <= opts.relchg
         break;
     end
     
     [tv, fid, f] = fval(D1X,D2X,KXF,beta,gamma);
     out.tv = [out.tv; tv];
     out.fid = [out.fid; fid];
     out.FX = [out.FX; f];
     PSNR1 = psnr(out.sol,I);
     out.PSNR = [out.PSNR; PSNR1];
     
     
     k = k + 1;

end

    
%% ------------------SUBFUNCTION-----------------------------
function opts = getopts(opts)

if ~isfield(opts,'maxitr')
    % maximum inner iteration number of ADMM 
    opts.maxitr = 400;
end

if ~isfield(opts,'delta')
    opts.delta = 1.618;
end

if ~isfield(opts,'N')
    opts.N = 10;
end

if ~isfield(opts,'rho')
    opts.rho = 1e-5;
end

if ~isfield(opts,'relchg')
    opts.relchg = 1.e-4;
end
if ~isfield(opts,'print')
    opts.print = 0;
end

%% ------------------SUBFUNCTION-----------------------------
function C = getC(F,H)

sizeF = size(F);

C.KtF = imfilter(F,H,'circular','corr');
C.eigsDtD = abs(psf2otf([1,-1],sizeF)).^2 + abs(psf2otf([1;-1],sizeF)).^2;
C.eigsKtK = abs(psf2otf(H,sizeF)).^2;
C.proI = abs(psf2otf([1],sizeF));
%% ------------------SUBFUNCTION-----------------------------
function [tv,fid,f] = fval(D1X,D2X,KXF,beta,gamma1)

[m n] = size(KXF);
tv =  sum(sum(sqrt(D1X.^2 + D2X.^2)));
fid = sum(ones(m*n,1)- exp(-gamma1.*(abs(KXF(:)))))/(1-exp(-gamma1));
f = tv + beta * fid;

function [D,Dt] = defDDt

D = @(U) ForwardD(U);
Dt = @(X,Y) Dive(X,Y);

function [Dux,Duy] = ForwardD(U)

Dux = [diff(U,1,2), U(:,1) - U(:,end)];
Duy = [diff(U,1,1); U(1,:) - U(end,:)];

function DtXY = Dive(X,Y)

DtXY = [X(:,end) - X(:, 1), -diff(X,1,2)];
DtXY = DtXY + [Y(end,:) - Y(1, :); -diff(Y,1,1)];
