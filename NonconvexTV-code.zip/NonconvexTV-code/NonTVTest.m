% Test NonconvexTV model
% Reference paper: Nonconvex-TV Based Image Restoration with Impulse Noise
% Removal, 10(3):1627-1667, 2017.
% @ X. Zhang, M. Bai, and M. K. Ng. 2017


function out = Test
%

clear; close all; 
path(path,genpath(pwd));

%% generate data -- see nested function below
[I,H,Bn,mu] = genData;

%% Run PLM 
tic;
out = PLM(H,Bn,mu,I);
t = toc;

% PSNR
PSNR = psnr(out.sol,I)

%% Plot result
figure(1);
subplot(121); 
imshow(Bn,[]);
title(sprintf('Corruption: %4.0f%%',NoiseLevel*100),'fontsize',13); 

subplot(122); 
imshow(out.sol,[]);
title(sprintf('SNR %4.2fdB, CPU %4.2fs, outIt %d, AllIt %d, PSNR %4.2fdB',SNR(out.sol,I),t,out.itr,out.allit,PSNR),'fontsize',13); 

fprintf('Corruption %2.0d%%, SNR(Recovered) %4.2fdB, PSNR(Recovered) %4.2fdB',NoiseLevel*100,SNR(out.sol),PSNR);
fprintf(' CPU %4.2fs, Iteration of PLM %d\n\n',t,out.itr);

%% nested function 
function [I,H,Bn,beta] = genData


I = double(imread('cameraman.tif'))/255;  % original image

H = fspecial('average',7);

NoiseLevel = 0.3;  % noise level

Bn = imfilter(I,H,'circular','conv');
Bn = imnoise(Bn,'salt & pepper',NoiseLevel);  % noisy and blury image

snr(Bn,I);



% suggested beta (not too bad)
switch NoiseLevel

    case 0.30; beta = 50;

    case 0.50; beta = 10;

    case 0.70; beta = 4;
        
    case 0.90; beta = 2;
        
    otherwise
        beta = input('Input beta:');
end

end

end
