This is the code for the NonconvexTV model,
see: Nonconvex-TV Based Image Restoration with Impulse Noise Removal, 
Xiongjun Zhang, Minru Bai, and Michael K. Ng, SIAM Journal on Imaging Sciences, 10(3):1627-1667, 2017.

@ Xiongjun Zhang, Minru Bai, and Michael K. Ng, May 2016.
If you have any questions, please feel free to contact xjzhang@mail.ccnu.edu.cn